package com.superLibra.APIResources;

public enum APIResources {
    Lookup("/lookup/"),
    NOMINET_URL("https://www.nominet.uk"),
    gTLD_DOMAIN("https://rdap.nominet.uk"),
    DNS_DOMAIN("/uk/domain/technical.uk"),
    DNS_DOMAIN_NON_EXISTING("/lookup/domain/testing");

    private String resource;

    APIResources(String resource) {
        this.resource = resource;
    }

    public String getResource() {
        return resource;
    }
}
