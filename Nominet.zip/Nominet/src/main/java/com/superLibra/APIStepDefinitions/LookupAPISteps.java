package com.superLibra.APIStepDefinitions;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.superLibra.APIResources.APIResources;
import org.testng.Assert;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;

public class LookupAPISteps {

	public int response = 0;

	@When("User calls existing nominet domain {string} with {string} and method {string}")
	public void user_calls_with_http_request(String domain, String resource, String method) throws IOException {
		APIResources requestDomain = APIResources.valueOf(domain);
		RestAssured.baseURI = requestDomain.getResource();
		APIResources resource1 = APIResources.valueOf(resource);
		response = given().log().all().header("Content-Type", "application/json").when().get(resource1.getResource()).then().extract().statusCode();
	}
	
	@When("User calls non existing nominet domain {string} with {string} and method {string}")
	public void user_calls_non_existing_with_http_request(String domain, String resource, String method) throws IOException {
		APIResources requestDomain = APIResources.valueOf(domain);
		RestAssured.baseURI = requestDomain.getResource();
		APIResources nonExisting = APIResources.valueOf(resource);
		response = given().log().all().header("Content-Type", "application/json").when().get(nonExisting.getResource()).then().extract().statusCode();
	}
	
	@Then("The API call success with status code {int}")
	public void the_api_call_got_success_with_status_code(int respCode) {
		Assert.assertEquals(respCode, response);
	}
}
