package com.superLibra.TestRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/java/com/superLibra/APIFeatures", glue = "com.superLibra.APIStepDefinitions", plugin = {
		"pretty" }, tags = "@Demo", monochrome = true, dryRun = false)
public class TestRunner {

}
