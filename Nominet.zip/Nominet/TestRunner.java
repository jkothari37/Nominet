package com.superLibra.TestRunner;

import static org.junit.Assert.fail;

import org.junit.Test;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.TestNGCucumberRunner;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\test\\java\\com\\superLibra\\APIFeatures", glue = {
		"com.superLibra.APIStepDefinitions" }, tags = "@Demo", plugin = { "pretty",
				"html:target\\cucumber-reports\\report.html", "testng:target\\testng-cucumber-reports\\cuketestng.xml"

},

		monochrome = true)

public class TestRunner {

}
